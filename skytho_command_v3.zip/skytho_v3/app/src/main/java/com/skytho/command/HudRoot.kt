package com.skytho.command

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlin.math.*

// ─────────────────────────────────────────────────────────────────────────────
//  COLOUR SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
private val BG        = Color(0xFF060A0C)
private val PANEL     = Color(0xFF0B1318)
private val BORDER    = Color(0xFF1A2830)
private val GREEN     = Color(0xFF00FF88)
private val GREEN_DIM = Color(0xFF007744)
private val AMBER     = Color(0xFFFFBF00)
private val AMBER_DIM = Color(0xFF6B5000)
private val RED       = Color(0xFFFF3333)
private val RED_DIM   = Color(0xFF5C0000)
private val CYAN      = Color(0xFF00D4FF)
private val CYAN_DIM  = Color(0xFF004455)
private val TEXT1     = Color(0xFFDDEEF5)
private val TEXT2     = Color(0xFF6B8EA0)
private val TEXT3     = Color(0xFF2A3D47)
private val SKY_TOP   = Color(0xFF001844)
private val SKY_BOT   = Color(0xFF0044AA)
private val GND_TOP   = Color(0xFF3D1E00)
private val GND_BOT   = Color(0xFF1A0A00)
private val MONO      = FontFamily.Monospace

// ─────────────────────────────────────────────────────────────────────────────
//  ROOT
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun HudRoot(vm: VM) {
    val conn  by vm.conn.collectAsState()
    val drone by vm.drone.collectAsState()
    val modal by vm.modal.collectAsState()
    val log   by vm.log.collectAsState()
    val joyL  by vm.joyL.collectAsState()
    val joyR  by vm.joyR.collectAsState()

    Box(Modifier.fillMaxSize().background(BG)) {

        // ── Main 3-column layout ──────────────────────────────────────────
        Row(Modifier.fillMaxSize()) {
            LeftPanel(Modifier.width(180.dp).fillMaxHeight(), drone, conn, vm)
            CentrePanel(Modifier.weight(1f).fillMaxHeight(), drone, joyL, joyR, vm)
            RightPanel(Modifier.width(180.dp).fillMaxHeight(), drone, conn, vm)
        }

        // ── Modal overlay ─────────────────────────────────────────────────
        AnimatedVisibility(modal != VM.Modal.NONE,
            enter = fadeIn(tween(180)),
            exit  = fadeOut(tween(180))
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.82f))) {
                when (modal) {
                    VM.Modal.SETUP -> SetupModal(vm)
                    VM.Modal.MODES -> ModeModal(vm, drone.mode)
                    VM.Modal.LOG   -> LogModal(vm, log)
                    else           -> {}
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  LEFT PANEL  — attitude + speed tape + left joystick
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun LeftPanel(modifier: Modifier, drone: DroneState, conn: ConnState, vm: VM) {
    Column(
        modifier
            .background(PANEL)
            .border(BorderStroke(0.5.dp, BORDER), RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
    ) {
        // Top: attitude data
        Column(
            Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PanelHeader("ATTITUDE")
            AttRow("ROLL",  drone.roll,  "°", AMBER)
            AttRow("PITCH", drone.pitch, "°", AMBER)
            AttRow("YAW",   drone.yaw,   "°", AMBER)

            Spacer(Modifier.height(4.dp))
            PanelHeader("POSITION")
            CoordRow("LAT", drone.lat)
            CoordRow("LON", drone.lon)
            Spacer(Modifier.weight(1f))

            // GPS status
            GpsCard(drone.fixType, drone.satellites)
        }

        // Bottom: left joystick (Roll / Pitch)
        Column(
            Modifier.height(150.dp).fillMaxWidth().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Joystick(
                vm.joyL,
                stickyY = false,
                color   = AMBER,
                onMove  = vm::joyLeftMove,
                onUp    = vm::joyLeftUp,
                modifier = Modifier.weight(1f).aspectRatio(1f)
            )
            Row(Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                JoyLabel("ROLL",  vm.joyL.collectAsState().value.x, AMBER)
                JoyLabel("PITCH", -vm.joyL.collectAsState().value.y, AMBER)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  CENTRE PANEL  —  AHI + speed/alt tapes + bottom status
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun CentrePanel(modifier: Modifier, drone: DroneState, joyL: Offset, joyR: Offset, vm: VM) {
    val conn by vm.conn.collectAsState()

    Column(modifier) {
        // Top bar
        TopBar(drone, conn, vm)

        // Main: tapes + AHI
        Row(Modifier.weight(1f).fillMaxWidth()) {
            // Speed tape
            SpeedTape(Modifier.width(44.dp).fillMaxHeight(), drone.groundSpeed)

            // AHI
            Box(Modifier.weight(1f).fillMaxHeight()) {
                AHI(drone.roll, drone.pitch, drone.heading,
                    Modifier.fillMaxSize().padding(vertical = 4.dp, horizontal = 2.dp))
            }

            // Altitude tape
            AltTape(Modifier.width(44.dp).fillMaxHeight(), drone.altRel, drone.climbRate)
        }

        // Bottom status strip
        BottomBar(drone, conn)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  RIGHT PANEL  — power + modes + right joystick
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun RightPanel(modifier: Modifier, drone: DroneState, conn: ConnState, vm: VM) {
    Column(
        modifier
            .background(PANEL)
            .border(BorderStroke(0.5.dp, BORDER), RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
    ) {
        // Top: power + flight data
        Column(
            Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PanelHeader("POWER")
            BatteryBar(drone.battPct, drone.voltage)

            Spacer(Modifier.height(4.dp))
            PanelHeader("FLIGHT")
            AttRow("SPD",  drone.groundSpeed, " m/s", GREEN)
            AttRow("ALT",  drone.altRel,      " m",   CYAN)
            AttRow("VSI",  drone.climbRate,   " m/s", if (drone.climbRate >= 0) GREEN else AMBER)

            Spacer(Modifier.height(4.dp))
            PanelHeader("QUICK")
            ActionBtn("TAKEOFF", GREEN, conn)  { vm.doTakeoff() }
            Spacer(Modifier.height(4.dp))
            ActionBtn("LAND",    AMBER, conn)  { vm.doLand() }
            Spacer(Modifier.height(4.dp))
            ActionBtn("RTL",     RED,   conn)  { vm.doRtl() }
            Spacer(Modifier.weight(1f))
        }

        // Bottom: right joystick (Yaw / Throttle)
        Column(
            Modifier.height(150.dp).fillMaxWidth().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Joystick(
                vm.joyR,
                stickyY = true,
                color   = GREEN,
                onMove  = vm::joyRightMove,
                onUp    = vm::joyRightUp,
                modifier = Modifier.weight(1f).aspectRatio(1f)
            )
            Row(Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                JoyLabel("YAW", vm.joyR.collectAsState().value.x, GREEN)
                JoyLabel("THR", -vm.joyR.collectAsState().value.y, GREEN)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TOP BAR
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun TopBar(drone: DroneState, conn: ConnState, vm: VM) {
    val connColor = when (conn) {
        ConnState.CAPTAIN    -> GREEN
        ConnState.ONLINE     -> CYAN
        ConnState.CONNECTING -> AMBER
        ConnState.OFFLINE    -> RED
    }
    val armed     = drone.armed
    val armedColor = if (armed) RED else GREEN

    // Pulse animation for armed state
    val inf = rememberInfiniteTransition(label = "arm")
    val armAlpha by inf.animateFloat(0.5f, 1f,
        infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "a")

    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .background(Color(0xFF080E12))
            .border(BorderStroke(0.5.dp, BORDER))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Brand
        Text("SKYTHO", color = GREEN, fontSize = 16.sp,
            fontWeight = FontWeight.Black, letterSpacing = 4.sp, fontFamily = MONO)

        Spacer(Modifier.width(10.dp))

        // Mode selector chip
        Chip(drone.mode, AMBER) { vm.openModes() }

        Spacer(Modifier.weight(1f))

        // Heading (single, here only)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("HDG  ", color = TEXT2, fontSize = 9.sp, fontFamily = MONO)
            Text(
                "%03d°".format(drone.heading.toInt()),
                color = TEXT1, fontSize = 13.sp,
                fontWeight = FontWeight.Bold, fontFamily = MONO
            )
            Spacer(Modifier.width(4.dp))
            Text(headingToRose(drone.heading), color = TEXT2, fontSize = 9.sp, fontFamily = MONO)
        }

        Spacer(Modifier.weight(1f))

        // Connection
        Chip(connLabel(conn), connColor) {
            if (conn != ConnState.OFFLINE) vm.doRequestCaptain()
            else vm.openSetup()
        }

        Spacer(Modifier.width(8.dp))

        // Log button
        Chip("LOG", TEXT2) { vm.openLog() }

        Spacer(Modifier.width(8.dp))

        // Settings
        Chip("⚙", TEXT2) { vm.openSetup() }

        Spacer(Modifier.width(12.dp))

        // ARM / DISARM
        Box(
            Modifier
                .border(BorderStroke(1.5.dp, armedColor.copy(alpha = if (armed) armAlpha else 1f)),
                    RoundedCornerShape(4.dp))
                .background(armedColor.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                .clickable { vm.armDisarm() }
                .padding(horizontal = 16.dp, vertical = 5.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (armed) "DISARM" else "ARM",
                color = armedColor.copy(alpha = if (armed) armAlpha else 1f),
                fontSize = 11.sp, fontWeight = FontWeight.Black,
                letterSpacing = 2.sp, fontFamily = MONO
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  BOTTOM BAR  —  compact status only, no duplicated values
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun BottomBar(drone: DroneState, conn: ConnState) {
    val log by remember { mutableStateOf("") }
    Row(
        Modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(Color(0xFF080E12))
            .border(BorderStroke(0.5.dp, BORDER))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        StatusDot(drone.sysStatus)
        Text("SYS: ${drone.sysStatus}", color = TEXT2, fontSize = 8.sp, fontFamily = MONO)
        Text("  ·  ", color = TEXT3, fontSize = 8.sp)
        Text("${drone.lat.let { "%.5f".format(it) }} / ${drone.lon.let { "%.5f".format(it) }}",
            color = TEXT2, fontSize = 8.sp, fontFamily = MONO)
        Text("  ·  ", color = TEXT3, fontSize = 8.sp)
        Text("ABS: ${"%.1f".format(drone.altAbs)}m", color = TEXT2, fontSize = 8.sp, fontFamily = MONO)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  AHI — clean aviation artificial horizon
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun AHI(roll: Float, pitch: Float, heading: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cx   = size.width  / 2f
        val cy   = size.height / 2f
        val r    = minOf(cx, cy) * 0.93f

        // Clip to circle
        val clip = Path().apply {
            addOval(Rect(cx - r, cy - r, cx + r, cy + r))
        }

        clipPath(clip) {
            // Horizon offset from pitch
            val pixPerDeg  = r / 28f   // 28° fills half the AHI
            val pitchPx    = pitch * pixPerDeg

            rotate(-roll, pivot = Offset(cx, cy)) {
                // Sky
                drawRect(
                    Brush.verticalGradient(
                        listOf(SKY_TOP, SKY_BOT),
                        startY = 0f,
                        endY   = cy + pitchPx
                    ),
                    topLeft = Offset(-size.width, -size.height * 2),
                    size    = Size(size.width * 3, size.height * 3 + cy + pitchPx)
                )

                // Ground
                drawRect(
                    Brush.verticalGradient(
                        listOf(GND_TOP, GND_BOT),
                        startY = cy + pitchPx,
                        endY   = cy + pitchPx + r
                    ),
                    topLeft = Offset(-size.width, cy + pitchPx),
                    size    = Size(size.width * 3, size.height * 3)
                )

                // Horizon line
                drawLine(
                    Color.White.copy(alpha = 0.95f),
                    Offset(-size.width, cy + pitchPx),
                    Offset(size.width * 2, cy + pitchPx),
                    strokeWidth = 1.8.dp.toPx()
                )

                // Pitch ladder
                for (deg in listOf(-20, -15, -10, -5, 5, 10, 15, 20)) {
                    val ly   = cy + pitchPx - deg * pixPerDeg
                    val isLong = abs(deg) % 10 == 0
                    val hw   = if (isLong) 22.dp.toPx() else 12.dp.toPx()
                    drawLine(
                        Color.White.copy(alpha = 0.7f),
                        Offset(cx - hw, ly), Offset(cx + hw, ly),
                        1.2.dp.toPx()
                    )
                    if (isLong) {
                        val td = 5.dp.toPx()
                        val dir = if (deg > 0) td else -td
                        drawLine(Color.White.copy(alpha = 0.7f),
                            Offset(cx - hw, ly), Offset(cx - hw, ly + dir), 1.dp.toPx())
                        drawLine(Color.White.copy(alpha = 0.7f),
                            Offset(cx + hw, ly), Offset(cx + hw, ly + dir), 1.dp.toPx())
                    }
                }
            }
        }

        // Roll arc (outside clip, fixed to screen)
        val arcR = r - 6.dp.toPx()
        for (deg in listOf(-60, -45, -30, -20, -10, 0, 10, 20, 30, 45, 60)) {
            val rad = Math.toRadians((deg - 90).toDouble())
            val len = if (deg % 30 == 0) 10.dp.toPx() else 6.dp.toPx()
            val x1 = cx + arcR * cos(rad).toFloat()
            val y1 = cy + arcR * sin(rad).toFloat()
            val x2 = cx + (arcR - len) * cos(rad).toFloat()
            val y2 = cy + (arcR - len) * sin(rad).toFloat()
            drawLine(
                if (deg == 0) Color.White else TEXT2.copy(alpha = 0.6f),
                Offset(x1, y1), Offset(x2, y2),
                if (deg % 30 == 0) 1.5.dp.toPx() else 0.8.dp.toPx()
            )
        }

        // Roll pointer (rotates with aircraft)
        rotate(-roll, pivot = Offset(cx, cy)) {
            val h = 9.dp.toPx(); val w = 5.dp.toPx()
            val y0 = cy - arcR + 1.dp.toPx()
            val path = Path().apply {
                moveTo(cx, y0); lineTo(cx - w, y0 + h); lineTo(cx + w, y0 + h); close()
            }
            drawPath(path, Color.White)
        }

        // Fixed aircraft symbol
        val wl = 26.dp.toPx(); val ws = 2.5.dp.toPx()
        drawLine(Color.White, Offset(cx - wl, cy), Offset(cx - 8.dp.toPx(), cy), ws)
        drawLine(Color.White, Offset(cx + 8.dp.toPx(), cy), Offset(cx + wl, cy), ws)
        drawLine(Color.White, Offset(cx - 8.dp.toPx(), cy), Offset(cx - 8.dp.toPx(), cy - 8.dp.toPx()), ws)
        drawLine(Color.White, Offset(cx + 8.dp.toPx(), cy), Offset(cx + 8.dp.toPx(), cy - 8.dp.toPx()), ws)
        drawCircle(Color.White, 3.dp.toPx(), center = Offset(cx, cy))

        // Outer ring
        drawCircle(BORDER.copy(alpha = 0.9f), r, center = Offset(cx, cy), style = Stroke(1.5.dp.toPx()))

        // Compass strip at bottom of AHI
        drawCompassStrip(cx, cy, r, heading)
    }
}

private fun DrawScope.drawCompassStrip(cx: Float, cy: Float, r: Float, heading: Float) {
    val stripH    = 20.dp.toPx()
    val stripW    = r * 1.5f
    val stripY    = cy + r - stripH - 4.dp.toPx()
    val ppd       = stripW / 50f   // pixels per degree (50° visible)

    drawRect(Color.Black.copy(alpha = 0.75f),
        topLeft = Offset(cx - stripW / 2, stripY),
        size    = Size(stripW, stripH))

    val base = heading.toInt()
    for (off in -30..30) {
        val deg = ((base + off) % 360 + 360) % 360
        val x   = cx + off * ppd
        val big = deg % 10 == 0
        val card = deg % 90 == 0
        if (x < cx - stripW / 2 || x > cx + stripW / 2) continue
        drawLine(
            if (card) Color.White else if (big) TEXT2 else TEXT3,
            Offset(x, stripY + stripH * 0.4f),
            Offset(x, stripY + stripH),
            if (big) 1.2.dp.toPx() else 0.5.dp.toPx()
        )
    }
    // Centre bug
    val bugPath = Path().apply {
        moveTo(cx, stripY + 2.dp.toPx())
        lineTo(cx - 4.dp.toPx(), stripY + 9.dp.toPx())
        lineTo(cx + 4.dp.toPx(), stripY + 9.dp.toPx())
        close()
    }
    drawPath(bugPath, CYAN)
}

// ─────────────────────────────────────────────────────────────────────────────
//  SPEED TAPE  (left)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun SpeedTape(modifier: Modifier, spd: Float) {
    BoxWithConstraints(modifier.background(PANEL).border(BorderStroke(0.5.dp, BORDER))) {
        val h = constraints.maxHeight.toFloat()
        val w = constraints.maxWidth.toFloat()
        Canvas(Modifier.fillMaxSize()) {
            val cy    = h / 2f
            val ppd   = h / 18f
            val label = "%.0f".format(spd)

            // Ticks
            for (v in 0..30) {
                val y = cy - (v - spd) * ppd
                if (y < 0f || y > h) continue
                val big = v % 5 == 0
                val lw  = if (big) w * 0.55f else w * 0.3f
                drawLine(
                    if (big) TEXT1 else TEXT3,
                    Offset(w - lw, y), Offset(w, y),
                    if (big) 1.2.dp.toPx() else 0.6.dp.toPx()
                )
            }

            // Current value box
            val bh = 22.dp.toPx()
            drawRect(PANEL,     topLeft = Offset(0f, cy - bh/2), size = Size(w, bh))
            drawRect(GREEN_DIM, topLeft = Offset(0f, cy - bh/2), size = Size(w, bh), style = Stroke(1.dp.toPx()))
        }

        // Text inside box
        Column(Modifier.align(Alignment.Center)) {
            Text("%.1f".format(spd), color = GREEN,
                fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
        }

        Text("SPD", color = TEXT2, fontSize = 7.sp, fontFamily = MONO,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  ALTITUDE TAPE  (right)  + VSI bar
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun AltTape(modifier: Modifier, alt: Float, vsi: Float) {
    BoxWithConstraints(modifier.background(PANEL).border(BorderStroke(0.5.dp, BORDER))) {
        val h = constraints.maxHeight.toFloat()
        val w = constraints.maxWidth.toFloat()
        Canvas(Modifier.fillMaxSize()) {
            val cy  = h / 2f
            val ppd = h / 30f

            // VSI bar on left edge
            val maxVsi = 5f
            val vsiNorm = (vsi / maxVsi).coerceIn(-1f, 1f)
            val vsiH = abs(vsiNorm) * cy * 0.8f
            val vsiY = if (vsiNorm >= 0) cy - vsiH else cy
            drawRect(if (vsi >= 0) GREEN.copy(alpha = 0.5f) else AMBER.copy(alpha = 0.5f),
                topLeft = Offset(0f, vsiY), size = Size(3.dp.toPx(), vsiH))

            // Ticks
            for (v in -5..100 step 1) {
                val y   = cy - (v - alt) * ppd
                if (y < 0f || y > h) continue
                val big = v % 5 == 0
                val lw  = if (big) w * 0.55f else w * 0.3f
                drawLine(
                    if (v == 0) RED else if (big) TEXT1 else TEXT3,
                    Offset(0f, y), Offset(lw, y),
                    if (v == 0) 2.dp.toPx() else if (big) 1.2.dp.toPx() else 0.6.dp.toPx()
                )
            }

            // Current value box
            val bh = 22.dp.toPx()
            drawRect(PANEL,    topLeft = Offset(0f, cy - bh/2), size = Size(w, bh))
            drawRect(CYAN_DIM, topLeft = Offset(0f, cy - bh/2), size = Size(w, bh), style = Stroke(1.dp.toPx()))
        }

        Column(Modifier.align(Alignment.Center)) {
            Text("%.1f".format(alt), color = CYAN,
                fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
        }

        Text("ALT", color = TEXT2, fontSize = 7.sp, fontFamily = MONO,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  JOYSTICK  —  clean canvas, correct normalised output
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun Joystick(
    valueFlow: StateFlow<Offset>,
    stickyY:  Boolean,
    color:    Color,
    onMove:   (Float, Float) -> Unit,
    onUp:     () -> Unit,
    modifier: Modifier = Modifier
) {
    val value by valueFlow.collectAsState()
    var size  by remember { mutableStateOf(IntSize(1, 1)) }
    var stickyYval by remember { mutableFloatStateOf(0f) }

    Box(
        modifier
            .onSizeChanged { size = it }
            .pointerInput(stickyY) {
                detectDragGestures(
                    onDragStart = { p ->
                        val cx = size.width / 2f; val cy = size.height / 2f
                        val r  = minOf(cx, cy) * 0.8f
                        val nx = ((p.x - cx) / r).coerceIn(-1f, 1f)
                        val ny = ((p.y - cy) / r).coerceIn(-1f, 1f)
                        if (stickyY) stickyYval = ny
                        onMove(nx, if (stickyY) stickyYval else ny)
                    },
                    onDrag = { c, _ ->
                        c.consume()
                        val cx = size.width / 2f; val cy = size.height / 2f
                        val r  = minOf(cx, cy) * 0.8f
                        val nx = ((c.position.x - cx) / r).coerceIn(-1f, 1f)
                        val ny = ((c.position.y - cy) / r).coerceIn(-1f, 1f)
                        if (stickyY) stickyYval = ny
                        onMove(nx, if (stickyY) stickyYval else ny)
                    },
                    onDragEnd    = { if (stickyY) onMove(0f, stickyYval) else onUp() },
                    onDragCancel = { if (stickyY) onMove(0f, stickyYval) else onUp() }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width  / 2f
            val cy = size.height / 2f
            val r  = minOf(cx, cy) * 0.88f
            val ir = r * 0.78f

            // Base ring
            drawCircle(TEXT3.copy(alpha = 0.5f), r, Offset(cx,cy), style = Stroke(0.8.dp.toPx()))
            // Inner guide ring
            drawCircle(TEXT3.copy(alpha = 0.25f), ir, Offset(cx,cy), style = Stroke(0.5.dp.toPx()))
            // Cross hairs
            drawLine(TEXT3, Offset(cx-r, cy), Offset(cx+r, cy), 0.5.dp.toPx())
            drawLine(TEXT3, Offset(cx, cy-r), Offset(cx, cy+r), 0.5.dp.toPx())

            // Knob
            val kx = cx + value.x * ir
            val ky = cy + value.y * ir
            val isActive = value != Offset.Zero
            if (isActive) {
                drawCircle(color.copy(alpha = 0.12f), 18.dp.toPx(), Offset(kx, ky))
                drawLine(color.copy(alpha = 0.4f), Offset(cx,cy), Offset(kx, ky), 1.dp.toPx())
            }
            drawCircle(if (isActive) color else TEXT3, 10.dp.toPx(), Offset(kx, ky))
            drawCircle(PANEL, 6.dp.toPx(), Offset(kx, ky))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SMALL COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun PanelHeader(text: String) {
    Text(text, color = TEXT3, fontSize = 7.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp, fontFamily = MONO)
    Spacer(Modifier.fillMaxWidth().height(0.5.dp).background(BORDER))
    Spacer(Modifier.height(2.dp))
}

@Composable
fun AttRow(label: String, value: Float, unit: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TEXT2, fontSize = 9.sp, fontFamily = MONO)
        Text("${"%.1f".format(value)}$unit", color = color,
            fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
    }
}

@Composable
fun CoordRow(label: String, value: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TEXT2, fontSize = 9.sp, fontFamily = MONO)
        Text("%.5f".format(value), color = CYAN,
            fontSize = 8.sp, fontFamily = MONO)
    }
}

@Composable
fun GpsCard(fix: Int, sats: Int) {
    val color = when { fix >= 3 -> GREEN; fix == 2 -> AMBER; else -> RED }
    val label = when { fix >= 6 -> "RTK"; fix >= 4 -> "DGPS"; fix == 3 -> "3D"; fix == 2 -> "2D"; else -> "NONE" }
    Row(
        Modifier.fillMaxWidth()
            .border(BorderStroke(0.5.dp, color.copy(alpha = 0.5f)), RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("GPS  $label", color = color, fontSize = 9.sp, fontFamily = MONO, fontWeight = FontWeight.Bold)
        Text("$sats SAT", color = color, fontSize = 9.sp, fontFamily = MONO)
    }
}

@Composable
fun BatteryBar(pct: Int, volts: Float) {
    val color = when { pct < 0 -> TEXT2; pct < 20 -> RED; pct < 40 -> AMBER; else -> GREEN }
    val fill  = if (pct >= 0) pct / 100f else 0f
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("BATT", color = TEXT2, fontSize = 9.sp, fontFamily = MONO)
            Text(if (pct >= 0) "$pct%" else "--", color = color,
                fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
        }
        Spacer(Modifier.height(3.dp))
        Box(Modifier.fillMaxWidth().height(5.dp).background(TEXT3, RoundedCornerShape(2.dp))) {
            Box(
                Modifier.fillMaxWidth(fill.coerceAtLeast(0.02f)).fillMaxHeight()
                    .background(color, RoundedCornerShape(2.dp))
            )
        }
        Spacer(Modifier.height(2.dp))
        Text("%.2fV".format(volts), color = TEXT2, fontSize = 8.sp, fontFamily = MONO)
    }
}

@Composable
fun ActionBtn(text: String, color: Color, conn: ConnState, onClick: () -> Unit) {
    val enabled = conn != ConnState.OFFLINE
    Box(
        Modifier.fillMaxWidth()
            .border(BorderStroke(1.dp, if (enabled) color.copy(alpha = 0.7f) else TEXT3),
                RoundedCornerShape(4.dp))
            .background(if (enabled) color.copy(alpha = 0.1f) else Color.Transparent,
                RoundedCornerShape(4.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) color else TEXT3,
            fontSize = 9.sp, fontWeight = FontWeight.Black,
            letterSpacing = 1.sp, fontFamily = MONO)
    }
}

@Composable
fun Chip(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .border(BorderStroke(1.dp, color.copy(alpha = 0.5f)), RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(3.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp, fontFamily = MONO)
    }
}

@Composable
fun JoyLabel(axis: String, value: Float, color: Color) {
    val v   = (value * 100).toInt()
    val txt = "$axis ${if(v >= 0) "+" else ""}$v%"
    Text(txt, color = if (abs(value) > 0.05f) color else TEXT3,
        fontSize = 7.sp, fontFamily = MONO)
}

@Composable
fun StatusDot(status: String) {
    val color = when (status) {
        "ACTIVE" -> GREEN; "STANDBY" -> AMBER; else -> TEXT3
    }
    Box(Modifier.size(6.dp).background(color, RoundedCornerShape(3.dp)))
}

// ─────────────────────────────────────────────────────────────────────────────
//  SETUP MODAL
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun SetupModal(vm: VM) {
    val ip   by vm.setupIp.collectAsState()
    val name by vm.setupName.collectAsState()
    var localIp   by remember(ip)   { mutableStateOf(ip) }
    var localName by remember(name) { mutableStateOf(name) }

    ModalCard(Modifier.width(400.dp)) {
        Text("SYSTEM CONFIGURATION", color = GREEN, fontSize = 12.sp,
            fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontFamily = MONO)
        Spacer(Modifier.height(16.dp))
        ModalField("SERVER IP", localIp, "192.168.1.x") { localIp = it }
        Spacer(Modifier.height(10.dp))
        ModalField("DEVICE NAME", localName, "SKYTHO APP") { localName = it }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f).border(BorderStroke(1.dp, RED.copy(alpha=0.4f)), RoundedCornerShape(4.dp))
                .clickable { vm.closeModal() }.padding(10.dp), contentAlignment = Alignment.Center) {
                Text("CANCEL", color = RED, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
            }
            Box(Modifier.weight(2f).background(GREEN.copy(alpha=0.15f), RoundedCornerShape(4.dp))
                .border(BorderStroke(1.dp, GREEN), RoundedCornerShape(4.dp))
                .clickable { vm.saveSetup(localIp, localName) }.padding(10.dp),
                contentAlignment = Alignment.Center) {
                Text("CONNECT", color = GREEN, fontSize = 9.sp,
                    fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontFamily = MONO)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MODE MODAL
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun ModeModal(vm: VM, currentMode: String) {
    val modes = listOf(
        "STABILIZE" to "Manual stabilisation",
        "ALT_HOLD"  to "Hold altitude",
        "LOITER"    to "GPS position hold",
        "POSHOLD"   to "Position hold",
        "AUTO"      to "Fly waypoint mission",
        "GUIDED"    to "External guidance",
        "SPORT"     to "Sport mode",
        "ACRO"      to "Full acrobatic",
        "RTL"       to "Return to launch",
        "LAND"      to "Auto land",
        "BRAKE"     to "Brake and hover"
    )
    ModalCard(Modifier.width(480.dp)) {
        Text("SELECT FLIGHT MODE", color = AMBER, fontSize = 12.sp,
            fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontFamily = MONO)
        Spacer(Modifier.height(12.dp))
        modes.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { (mode, desc) ->
                    val sel = mode == currentMode
                    Box(
                        Modifier.weight(1f)
                            .border(BorderStroke(1.dp, if (sel) AMBER else BORDER), RoundedCornerShape(4.dp))
                            .background(if (sel) AMBER_DIM else PANEL, RoundedCornerShape(4.dp))
                            .clickable { vm.doMode(mode) }
                            .padding(vertical = 7.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(mode, color = if (sel) AMBER else TEXT1, fontSize = 8.sp,
                                fontWeight = FontWeight.Bold, fontFamily = MONO, textAlign = TextAlign.Center)
                            Text(desc, color = TEXT2, fontSize = 6.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
                repeat(3 - row.size) { Box(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(5.dp))
        }
        Box(Modifier.fillMaxWidth().border(BorderStroke(1.dp, RED.copy(alpha=0.4f)), RoundedCornerShape(4.dp))
            .clickable { vm.closeModal() }.padding(8.dp), contentAlignment = Alignment.Center) {
            Text("CANCEL", color = RED, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  LOG MODAL
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun LogModal(vm: VM, logEntries: List<FlightLog>) {
    val listState = rememberLazyListState()
    LaunchedEffect(logEntries.size) {
        if (logEntries.isNotEmpty()) listState.animateScrollToItem(logEntries.size - 1)
    }
    ModalCard(Modifier.width(420.dp).fillMaxHeight(0.8f)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text("FLIGHT LOG", color = CYAN, fontSize = 12.sp,
                fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontFamily = MONO)
            Box(Modifier.border(BorderStroke(1.dp, RED.copy(alpha=0.4f)), RoundedCornerShape(3.dp))
                .clickable { vm.closeModal() }.padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text("CLOSE", color = RED, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = MONO)
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
            items(logEntries.reversed()) { entry ->
                val col = when {
                    entry.isFailsafe -> RED
                    entry.severity <= 3 -> RED
                    entry.severity <= 4 -> AMBER
                    else -> TEXT2
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    .background(if (entry.isFailsafe) RED_DIM else Color.Transparent, RoundedCornerShape(2.dp))
                    .padding(4.dp)) {
                    Text("[${sevLabel(entry.severity)}] ", color = col, fontSize = 8.sp, fontFamily = MONO,
                        fontWeight = FontWeight.Bold, modifier = Modifier.width(60.dp))
                    Text(entry.text, color = TEXT1, fontSize = 8.sp, fontFamily = MONO,
                        modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("${logEntries.size} entries", color = TEXT2, fontSize = 7.sp, fontFamily = MONO)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MODAL HELPERS
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun ModalCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier
                .background(PANEL, RoundedCornerShape(8.dp))
                .border(BorderStroke(1.dp, BORDER), RoundedCornerShape(8.dp))
                .padding(20.dp),
            content = content
        )
    }
}

@Composable
fun ModalField(label: String, value: String, hint: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = TEXT2, fontSize = 8.sp, letterSpacing = 1.sp, fontFamily = MONO)
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value       = value,
            onValueChange = onChange,
            singleLine  = true,
            textStyle   = TextStyle(color = TEXT1, fontSize = 13.sp, fontFamily = MONO),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
            modifier    = Modifier.fillMaxWidth()
                .background(BG, RoundedCornerShape(3.dp))
                .border(BorderStroke(1.dp, BORDER), RoundedCornerShape(3.dp))
                .padding(10.dp)
        ) { inner ->
            if (value.isEmpty())
                Text(hint, color = TEXT3, fontSize = 13.sp, fontFamily = MONO)
            inner()
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────
private fun headingToRose(h: Float): String {
    val dirs = listOf("N","NNE","NE","ENE","E","ESE","SE","SSE",
        "S","SSW","SW","WSW","W","WNW","NW","NNW")
    return dirs[((h + 11.25f) / 22.5f).toInt() % 16]
}
private fun connLabel(c: ConnState) = when (c) {
    ConnState.CAPTAIN    -> "CAPTAIN"
    ConnState.ONLINE     -> "ONLINE"
    ConnState.CONNECTING -> "CONN…"
    ConnState.OFFLINE    -> "OFFLINE"
}
private fun sevLabel(sev: Int) = when (sev) {
    0 -> "EMRG"; 1 -> "ALRT"; 2 -> "CRIT"; 3 -> "ERR"
    4 -> "WARN"; 5 -> "NOTE"; 6 -> "INFO"; else -> "DBG"
}
