package com.skytho.command

import android.app.Application
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class VM(app: Application) : AndroidViewModel(app) {

    val hub = HubConnection(app)

    // ── Expose hub state directly (no duplication) ─────────────────────────
    val conn:  StateFlow<ConnState>       = hub.conn
    val drone: StateFlow<DroneState>      = hub.state
    val log:   StateFlow<List<FlightLog>> = hub.log

    // ── Joystick values -1..+1 ─────────────────────────────────────────────
    // Left stick:  X = Roll, Y = Pitch (inverted — forward = negative pitch angle)
    // Right stick: X = Yaw, Y = Throttle (inverted — up = higher throttle)
    private val _joyL = MutableStateFlow(Offset.Zero)
    private val _joyR = MutableStateFlow(Offset.Zero)
    val joyL: StateFlow<Offset> = _joyL.asStateFlow()
    val joyR: StateFlow<Offset> = _joyR.asStateFlow()

    // Throttle sticky Y value (persists when finger lifts)
    private var throttleY = 0f   // -1 = up = full throttle, +1 = down = zero

    // ── Modal state ────────────────────────────────────────────────────────
    private val _modal = MutableStateFlow(Modal.NONE)
    val modal: StateFlow<Modal> = _modal.asStateFlow()
    enum class Modal { NONE, SETUP, MODES, LOG }

    // ── Setup state ────────────────────────────────────────────────────────
    private val _setupIp   = MutableStateFlow(hub.serverIp)
    private val _setupName = MutableStateFlow(hub.deviceName)
    val setupIp:   StateFlow<String> = _setupIp.asStateFlow()
    val setupName: StateFlow<String> = _setupName.asStateFlow()

    // RC channel values (1000-2000 µs)
    val ch1: Int get() = pwm(_joyL.value.x)           // Roll
    val ch2: Int get() = pwm(-_joyL.value.y)          // Pitch  (stick up = fly forward = positive pitch)
    val ch3: Int get() = pwmThrottle(throttleY)        // Throttle
    val ch4: Int get() = pwm(_joyR.value.x)            // Yaw

    private val vibrator: Vibrator by lazy { app.getSystemService(Vibrator::class.java) }

    init {
        if (!hub.hasIp()) _modal.value = Modal.SETUP
        hub.start()
        startRcLoop()
    }

    // ── RC send loop – 10Hz ───────────────────────────────────────────────
    private fun startRcLoop() {
        viewModelScope.launch {
            while (isActive) {
                val c = conn.value
                if (c == ConnState.ONLINE || c == ConnState.CAPTAIN) {
                    hub.rcOverride(ch1, ch2, ch3, ch4)
                }
                delay(100)
            }
        }
    }

    // ── Joystick callbacks ────────────────────────────────────────────────
    fun joyLeftMove(x: Float, y: Float)  { _joyL.value = Offset(x, y) }
    fun joyLeftUp()                       { _joyL.value = Offset.Zero }
    fun joyRightMove(x: Float, y: Float) {
        throttleY = y   // sticky throttle: remember Y
        _joyR.value = Offset(x, y)
    }
    fun joyRightUp() {
        // Release X (yaw) but keep throttle position
        _joyR.value = Offset(0f, throttleY)
    }

    // ── Commands ──────────────────────────────────────────────────────────
    fun armDisarm() {
        if (drone.value.armed) hub.disarm() else hub.arm()
        buzz(if (drone.value.armed) shortArrayOf(50, 80, 50) else shortArrayOf(200))
    }
    fun doTakeoff(alt: Float = 5f)  { hub.takeoff(alt); buzz(shortArrayOf(100)) }
    fun doLand()                    { hub.land();        buzz(shortArrayOf(50,50,50)) }
    fun doRtl()                     { hub.rtl();         buzz(shortArrayOf(100,50,100)) }
    fun doMode(m: String)           { hub.setMode(m);    closeModal() }
    fun doRequestCaptain()          { hub.requestCaptain(); buzz(shortArrayOf(30)) }

    // ── Modal ──────────────────────────────────────────────────────────────
    fun openSetup()  { _setupIp.value = hub.serverIp; _setupName.value = hub.deviceName; _modal.value = Modal.SETUP }
    fun openModes()  { _modal.value = Modal.MODES }
    fun openLog()    { _modal.value = Modal.LOG }
    fun closeModal() { _modal.value = Modal.NONE }

    fun saveSetup(ip: String, name: String) {
        hub.serverIp   = ip.trim()
        hub.deviceName = name.trim().ifEmpty { "SKYTHO APP" }
        hub.reconnect()
        closeModal()
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    private fun pwm(n: Float)            = (1500 + n * 500).toInt().coerceIn(1000, 2000)
    private fun pwmThrottle(y: Float)    = (1000 + (-y * 0.5f + 0.5f) * 1000).toInt().coerceIn(1000, 2000)

    private fun buzz(ms: ShortArray) {
        try {
            val longs = LongArray(ms.size + 1) { i -> if (i == 0) 0L else ms[i-1].toLong() }
            vibrator.vibrate(VibrationEffect.createWaveform(longs, -1))
        } catch (_: Exception) {}
    }

    override fun onCleared() { super.onCleared(); hub.stop() }
}
