package com.skytho.command

import android.app.Application

class SkythoApp : Application() {
    companion object { lateinit var instance: SkythoApp }
    override fun onCreate() { super.onCreate(); instance = this }
}

// ── Flight state ───────────────────────────────────────────────────────────────
data class DroneState(
    val armed:       Boolean = false,
    val mode:        String  = "---",
    val roll:        Float   = 0f,      // degrees
    val pitch:       Float   = 0f,
    val yaw:         Float   = 0f,
    val heading:     Float   = 0f,      // 0-360
    val altRel:      Float   = 0f,      // metres AGL
    val altAbs:      Float   = 0f,
    val groundSpeed: Float   = 0f,      // m/s
    val climbRate:   Float   = 0f,      // m/s positive=up
    val lat:         Double  = 0.0,
    val lon:         Double  = 0.0,
    val battPct:     Int     = -1,
    val voltage:     Float   = 0f,
    val fixType:     Int     = 0,
    val satellites:  Int     = 0,
    val sysStatus:   String  = "OFFLINE"
)

data class FlightLog(
    val text:       String,
    val severity:   Int,     // 0=emerg .. 7=debug  (MAVLink severity)
    val isFailsafe: Boolean = false,
    val ts:         Long    = System.currentTimeMillis()
)

enum class ConnState { OFFLINE, CONNECTING, ONLINE, CAPTAIN }
