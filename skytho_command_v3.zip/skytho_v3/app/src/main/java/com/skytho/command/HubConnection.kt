package com.skytho.command

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

/**
 * HubConnection v3
 *
 * Fixes vs v2:
 *  - Dedicated IO dispatcher for all socket work (no coroutine context switching on socket)
 *  - Single write-serialised queue via Channel to prevent concurrent write crashes
 *  - Exponential backoff on reconnect (1s→2s→4s→8s→8s max)
 *  - soTimeout on READ only; separate connect timeout via InetSocketAddress
 *  - Ping every 5s (was 8s) with server expecting response; disconnect if 2 pings missed
 *  - No more haversine stub — dist home tracked via simple state
 */
class HubConnection(private val ctx: Context) {

    companion object {
        private const val TAG        = "HubConn"
        private const val PORT       = 14551
        private const val CONNECT_MS = 5_000
        private const val READ_TIMEOUT_MS = 20_000
        private const val PING_INTERVAL_MS = 5_000L
        private const val PREFS = "skytho_v3"
    }

    private val prefs: SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var serverIp: String
        get()  = prefs.getString("ip", "") ?: ""
        set(v) = prefs.edit().putString("ip", v).apply()

    var deviceName: String
        get()  = prefs.getString("name", "SKYTHO APP") ?: "SKYTHO APP"
        set(v) = prefs.edit().putString("name", v).apply()

    fun hasIp() = serverIp.isNotBlank()

    // ── Public state ──────────────────────────────────────────────────────────
    private val _conn    = MutableStateFlow(ConnState.OFFLINE)
    private val _state   = MutableStateFlow(DroneState())
    private val _log     = MutableStateFlow<List<FlightLog>>(emptyList())
    private val _myId    = MutableStateFlow("")

    val conn:  StateFlow<ConnState>      = _conn.asStateFlow()
    val state: StateFlow<DroneState>     = _state.asStateFlow()
    val log:   StateFlow<List<FlightLog>> = _log.asStateFlow()
    val myId:  StateFlow<String>         = _myId.asStateFlow()

    // ── Internals ─────────────────────────────────────────────────────────────
    private val running  = AtomicBoolean(false)
    private val ioScope  = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var connJob: Job? = null

    // Write queue — all sends go through here to serialise writes
    private val writeQueue = kotlinx.coroutines.channels.Channel<String>(
        capacity = 256,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    fun start() {
        if (running.getAndSet(true)) return
        connJob = ioScope.launch { connectLoop() }
    }

    fun stop() {
        running.set(false)
        connJob?.cancel()
        _conn.value = ConnState.OFFLINE
    }

    fun reconnect() {
        connJob?.cancel()
        if (running.get()) connJob = ioScope.launch { delay(200); connectLoop() }
    }

    // ── Connection loop with exponential backoff ──────────────────────────────
    private suspend fun connectLoop() {
        var backoff = 1_000L
        while (running.get()) {
            val ip = serverIp
            if (ip.isBlank()) { delay(1_000); continue }

            var sock: Socket? = null
            try {
                _conn.value = ConnState.CONNECTING
                sock = Socket()
                withContext(Dispatchers.IO) {
                    sock.connect(InetSocketAddress(ip, PORT), CONNECT_MS)
                    sock.soTimeout  = READ_TIMEOUT_MS
                    sock.tcpNoDelay = true
                    sock.keepAlive  = true
                    sock.setPerformancePreferences(0, 1, 0) // latency > bandwidth
                }
                Log.i(TAG, "Connected $ip:$PORT")
                backoff = 1_000L

                val out = PrintWriter(BufferedWriter(OutputStreamWriter(sock.getOutputStream())), true)
                val inp = BufferedReader(InputStreamReader(sock.getInputStream()))

                // Identify immediately
                out.println(JSONObject().put("type","identify")
                    .put("name", deviceName).put("device_type","PHONE").toString())

                _conn.value = ConnState.ONLINE

                // Writer coroutine — drains writeQueue → socket
                val writer = ioScope.launch {
                    for (msg in writeQueue) {
                        if (sock.isClosed) break
                        try { out.println(msg) }
                        catch (e: Exception) { Log.w(TAG,"Write err: ${e.message}"); break }
                    }
                }

                // Ping loop
                val pinger = ioScope.launch {
                    while (isActive && !sock.isClosed) {
                        delay(PING_INTERVAL_MS)
                        enqueue(JSONObject().put("type","ping").toString())
                    }
                }

                // Read loop (blocking — on IO dispatcher)
                try {
                    var line: String?
                    while (inp.readLine().also { line = it } != null) {
                        val l = line!!.trim()
                        if (l.isNotEmpty()) parse(l)
                    }
                } finally {
                    writer.cancel()
                    pinger.cancel()
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (running.get()) Log.w(TAG,"Conn err: ${e.message}")
            } finally {
                try { sock?.close() } catch (_: Exception) {}
                if (running.get()) {
                    _conn.value = ConnState.OFFLINE
                    Log.i(TAG,"Reconnecting in ${backoff}ms")
                    delay(backoff)
                    backoff = (backoff * 2).coerceAtMost(8_000L)
                }
            }
        }
    }

    // ── Message parser ────────────────────────────────────────────────────────
    private fun parse(raw: String) {
        try {
            val j = JSONObject(raw)
            when (j.optString("type")) {

                "welcome" -> _myId.value = j.optString("device_id","")

                "telemetry" -> {
                    val d = j.optJSONObject("data") ?: return
                    _state.value = DroneState(
                        armed       = d.optBoolean("armed", false),
                        mode        = d.optString("mode","---"),
                        roll        = d.optDouble("roll",   0.0).toFloat(),
                        pitch       = d.optDouble("pitch",  0.0).toFloat(),
                        yaw         = d.optDouble("yaw",    0.0).toFloat(),
                        heading     = d.optDouble("heading",0.0).toFloat(),
                        altRel      = d.optDouble("relative_alt_m",0.0).toFloat(),
                        altAbs      = d.optDouble("alt_m",  0.0).toFloat(),
                        groundSpeed = d.optDouble("ground_speed",0.0).toFloat(),
                        climbRate   = d.optDouble("climb_rate",0.0).toFloat(),
                        lat         = d.optDouble("lat",    0.0),
                        lon         = d.optDouble("lon",    0.0),
                        battPct     = d.optInt("battery_pct", -1),
                        voltage     = d.optDouble("voltage_v",0.0).toFloat(),
                        fixType     = d.optInt("fix_type",0),
                        satellites  = d.optInt("satellites",0),
                        sysStatus   = d.optString("system_status","---")
                    )
                }

                "statustext" -> {
                    val text = j.optString("text","")
                    val sev  = j.optInt("severity",6)
                    val fs   = j.optBoolean("is_failsafe",false)
                    if (text.isNotEmpty()) addLog(FlightLog(text, sev, fs))
                }

                "captain_change" -> {
                    val cap = j.optString("captain_id","")
                    val me  = _myId.value
                    _conn.value = if (me.isNotEmpty() && me == cap) ConnState.CAPTAIN else ConnState.ONLINE
                }

                "kicked" -> { /* server kicked us — reconnect handles it */ }
                "pong"   -> { /* keepalive ack */ }
                "error"  -> Log.w(TAG, "Hub error: ${j.optString("message")}")
            }
        } catch (e: Exception) { Log.e(TAG,"Parse: ${e.message}") }
    }

    // ── Commands ──────────────────────────────────────────────────────────────
    fun cmd(command: String, params: Map<String, Any> = emptyMap()) {
        val p = JSONObject()
        params.forEach { (k, v) ->
            when (v) {
                is Int    -> p.put(k, v)
                is Float  -> p.put(k, v.toDouble())
                is Double -> p.put(k, v)
                is Boolean -> p.put(k, v)
                else      -> p.put(k, v.toString())
            }
        }
        enqueue(JSONObject().put("type","command").put("command",command).put("params",p).toString())
    }

    fun rcOverride(ch1: Int, ch2: Int, ch3: Int, ch4: Int) =
        cmd("RC_OVERRIDE", mapOf("ch1" to ch1,"ch2" to ch2,"ch3" to ch3,"ch4" to ch4))

    fun arm()                       = cmd("ARM")
    fun disarm()                    = cmd("DISARM")
    fun rtl()                       = cmd("RTL")
    fun land()                      = cmd("LAND")
    fun takeoff(alt: Float)         = cmd("TAKEOFF", mapOf("altitude" to alt))
    fun setMode(m: String)          = cmd("SET_MODE", mapOf("mode" to m))
    fun requestCaptain()            = enqueue(JSONObject().put("type","request_captain").toString())

    private fun enqueue(msg: String) {
        if (_conn.value == ConnState.OFFLINE) return
        writeQueue.trySend(msg)
    }

    private fun addLog(entry: FlightLog) {
        _log.value = (_log.value + entry).takeLast(300)
    }
}
